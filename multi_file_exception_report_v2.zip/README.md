# Multi-File Exception Report (v2)

Generates comparison reports for multiple Excel files (MenuF, AuthP, OpSett).
- Baseline = first sheet of each file
- Compares with all other sheets
- Groups comparison columns logically (e.g., Include In Updates, Security Level)
- Highlights differences (yellow fill)

## Setup (GitHub Codespaces)

1. Create new GitHub repository (empty).
2. Upload these files:
   - `main.py`
   - `config.json`
   - `requirements.txt`
   - `.gitignore`
3. Open repository in Codespaces.
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Upload input Excel files (keep names as in `config.json`):
   - `Combined_input_AuthP.xlsx`
   - `Combined_input_OpSett.xlsx`
   - `Combined_input_MenuF.xlsx`
6. Run script:
   ```bash
   python main.py
   ```
7. Outputs will be generated as:
   ```
   Compare_Result_Combined_input_AuthP.xlsx
   Compare_Result_Combined_input_OpSett.xlsx
   Compare_Result_Combined_input_MenuF.xlsx
   ```

---

## Requirements
- pandas
- openpyxl
