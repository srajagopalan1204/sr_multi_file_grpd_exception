import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import PatternFill
import json
import os

def log(msg):
    print(f"[LOG] {msg}")

def group_columns(columns):
    """
    Group columns by base name before underscore (e.g., 'Include In Updates', 'Security Level')
    """
    grouped = {}
    for col in columns:
        if "_" in col:
            base = "_".join(col.split("_")[:-1])  # remove last segment (env name)
        else:
            base = col
        grouped.setdefault(base, []).append(col)
    # Flatten preserving group order
    ordered = []
    for base, cols in grouped.items():
        ordered.extend(cols)
    return ordered

def process_file(filename, key_cols, compare_cols):
    # Load workbook
    excel = pd.ExcelFile(filename, engine='openpyxl')
    sheet_names = excel.sheet_names
    log(f"Processing file: {filename} | Sheets found: {sheet_names}")

    # Baseline sheet
    baseline_name = sheet_names[0]
    baseline = pd.read_excel(filename, sheet_name=baseline_name, dtype=str).fillna("")
    baseline = baseline[key_cols + compare_cols]

    # Initialize output with key columns
    output = baseline[key_cols].drop_duplicates().copy()

    # Add baseline compare columns
    for col in compare_cols:
        output[f"{col}_{baseline_name}"] = baseline[col]

    # Process each additional sheet
    for sheet in sheet_names[1:]:
        df = pd.read_excel(filename, sheet_name=sheet, dtype=str).fillna("")
        df = df[key_cols + compare_cols]
        merged = pd.merge(output[key_cols], df, on=key_cols, how='left')
        for col in compare_cols:
            output[f"{col}_{sheet}"] = merged[col]

    # Reorder columns: key columns + grouped compare columns
    compare_cols_generated = [c for c in output.columns if c not in key_cols]
    ordered_cols = key_cols + group_columns(compare_cols_generated)
    output = output[ordered_cols]

    # Save temporary output
    output_file = f"Compare_Result_{filename}"
    output.to_excel(output_file, index=False, engine='openpyxl')

    # Highlight differences
    wb = load_workbook(output_file)
    ws = wb.active
    yellow_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    headers = [cell.value for cell in ws[1]]

    for base in compare_cols:
        base_col = f"{base}_{baseline_name}"
        if base_col in headers:
            base_idx = headers.index(base_col) + 1
            for sheet in sheet_names[1:]:
                comp_col = f"{base}_{sheet}"
                if comp_col in headers:
                    comp_idx = headers.index(comp_col) + 1
                    for row in range(2, ws.max_row + 1):
                        base_val = ws.cell(row=row, column=base_idx).value
                        comp_val = ws.cell(row=row, column=comp_idx).value
                        if base_val != comp_val:
                            ws.cell(row=row, column=comp_idx).fill = yellow_fill

    wb.save(output_file)
    log(f"Output saved: {output_file}")

def main():
    # Load config
    with open("config.json", "r") as f:
        config = json.load(f)

    # Process each file
    for file, settings in config.items():
        if not os.path.exists(file):
            log(f"File not found: {file}, skipping...")
            continue
        process_file(file, settings["key_cols"], settings["compare_cols"])

    log("=== All files processed ===")

if __name__ == "__main__":
    main()